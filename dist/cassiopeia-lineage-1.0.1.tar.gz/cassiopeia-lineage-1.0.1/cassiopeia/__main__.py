#!/usr/bin/env python

import Cassiopeia

def main():
    print("Congrats, you've entered the program!")
